import numpy as np

def my_numpy_journey_array_full_random(param_1, param_2):
    a = np.random.rand(param_1, param_2)
    return a


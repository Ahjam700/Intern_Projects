import numpy as np

def my_numpy_journey_add(param_1, param_2):
    return np.add(param_1, param_2)

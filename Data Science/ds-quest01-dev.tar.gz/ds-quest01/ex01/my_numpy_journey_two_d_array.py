import numpy as np

def my_numpy_journey_two_d_array(param_1):

    return np.array(param_1)

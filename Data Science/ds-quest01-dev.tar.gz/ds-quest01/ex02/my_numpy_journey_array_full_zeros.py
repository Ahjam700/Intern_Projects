import numpy as np

def my_numpy_journey_array_full_zeros(param_1):

    return np.zeros(param_1)



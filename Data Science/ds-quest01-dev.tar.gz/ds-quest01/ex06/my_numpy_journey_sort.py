import numpy as np

def my_numpy_journey_sort(param_1):
    return np.sort(param_1)


# Welcome to My Open The Iris
Welcome to My Open The Iris! This project aims to tackling the challenge and to state the desired outcome or benefit of using the project, this tool offers a solution that's easy to install and use
## Task
The problem is creating a solution that automates and optimizes and the challenge lies in mention specific obstacles, such as scalability, efficiency, or user customization.

## Description
I have solved this problem by implementing by brief description of my solution, like a framework, algorithm, or system that addresses the challenge.

## Installation
No installation but sklearn and numpy was imported.

## Usage

```
My Open The Iris works by briefly describing the core function like processing input data or executing tasks, automatically performing (key steps) to produce (output or result) based on the provided arguments.
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
qwasar
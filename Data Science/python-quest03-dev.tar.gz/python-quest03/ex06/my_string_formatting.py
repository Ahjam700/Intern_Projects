def my_string_formatting(firstname, lastname, age):
    formatted_string = f"Hello, my name is {firstname} {lastname}, I'm {age}."
    print(formatted_string)


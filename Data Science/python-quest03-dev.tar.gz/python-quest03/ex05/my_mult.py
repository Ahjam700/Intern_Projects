def my_mult(param_e, param_f):
    return param_e * param_f
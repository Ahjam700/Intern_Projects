def my_is_negative(param):
    if param < 0:
        return 0
    else:
        return 1
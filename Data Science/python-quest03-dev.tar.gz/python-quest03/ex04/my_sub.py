def my_sub(param_c, param_d):
    return param_c - param_d
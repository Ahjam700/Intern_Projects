def my_add(param_a, param_b):
    return param_a + param_b
nbr = 10
if (nbr > 20):
  print("nbr is greater than 20")
else:
  print("nbr is less than 20")
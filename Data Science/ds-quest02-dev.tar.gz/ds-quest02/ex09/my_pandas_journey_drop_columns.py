import pandas as pd

def my_pandas_journey_drop_columns(param_1, param_2):
    a = param_1.drop(columns=param_2)
    return a
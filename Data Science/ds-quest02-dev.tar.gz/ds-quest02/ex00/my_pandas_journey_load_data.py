import pandas as pd

def my_pandas_journey_load_data(param_1):
    df = pd.read_csv(param_1)
    return df


import pandas as pd

def my_pandas_journey_extract_columns(param_1):
    df = pd.DataFrame(param_1)
    return df
import pandas as pd

def my_pandas_journey_filtering(param_1):
    return param_1.query('Index == "A"')
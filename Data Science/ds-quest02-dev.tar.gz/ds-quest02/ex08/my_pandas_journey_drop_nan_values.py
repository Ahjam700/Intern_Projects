import pandas as pd

def my_pandas_journey_drop_nan_values(param_1):
    a = param_1.dropna()
    return a
import pandas as pd

def my_pandas_journey_return_n_rows(param_1, param_2):
    return param_1.iloc[:param_2]
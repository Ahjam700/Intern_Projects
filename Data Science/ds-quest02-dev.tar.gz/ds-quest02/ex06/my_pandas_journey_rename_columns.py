import pandas as pd

def my_pandas_journey_rename_columns(param_1, param_2, param_3):
    return param_1.rename(columns={param_2: param_3})
import pandas as pd

def my_pandas_journey_return_n_columns(param_1, param_2):
    a = param_1.iloc[:,: param_2]
    return a
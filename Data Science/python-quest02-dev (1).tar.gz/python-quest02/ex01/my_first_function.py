def my_first_function():
    print ("my_first_function")
my_first_function()
def detonation_in(seconds_left):
    print("detonation in... " + str(seconds_left) + " seconds.")
timer = 10
while (timer > 0):
    detonation_in(timer)
    timer -= 1  # Decrement the timer to avoid an infinite loop

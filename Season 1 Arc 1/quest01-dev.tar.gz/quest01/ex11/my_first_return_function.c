#include <stdio.h>

// Function that returns the number 7
int my_get_seven() {
    return 7;
}

int main() {
    // Call the function and print the returned value
    printf("%d\n", my_get_seven());
    return 0;
}

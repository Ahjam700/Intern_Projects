#include <stdio.h>

int main() {
  char my_letter = 'c';

  printf("%c\n", my_letter);
  return 0;
}

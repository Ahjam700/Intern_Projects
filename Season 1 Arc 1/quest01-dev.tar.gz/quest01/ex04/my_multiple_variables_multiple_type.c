#include <stdio.h>

int main() {
  int my_age = 34;
  char *my_name = "Luke";
  char my_comma = ',';

  printf("Hello %s%c I'm %d years old.\n", my_name, my_comma, my_age);
  return 0;
}
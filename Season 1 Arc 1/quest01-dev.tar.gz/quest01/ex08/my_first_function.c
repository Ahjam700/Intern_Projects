#include <stdio.h>

// Function prototype
void my_first_function();

// Function definition
void my_first_function() {
    printf("my_first_function\n");
}

int main() {
    // Calling the function
    my_first_function();

    return 0;
}

#include <stdio.h>

// Function to check if the character is a space (' ')
int my_isspace(char param_1) {
    // Check if the character is a space (space character ' ')
    if (param_1 == ' ') {
        return 1;  // The character is a space
    }
    else {
        return 0;  // The character is not a space
    }
}

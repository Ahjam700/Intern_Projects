#include <stdio.h>

int main() {
  int index = 0;

  // Loop will run until index reaches 100
  while (index < 100) {  
    printf("I want to code\n");
    index++;  // Increment index after each iteration
  }
  return 0;
}

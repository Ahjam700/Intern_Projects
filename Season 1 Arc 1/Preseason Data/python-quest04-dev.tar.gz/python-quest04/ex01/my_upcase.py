def my_upcase(string):
    capital_string = string.upper()
    return capital_string



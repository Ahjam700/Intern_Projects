def my_size(string):
    string_size = len(string)
    return string_size
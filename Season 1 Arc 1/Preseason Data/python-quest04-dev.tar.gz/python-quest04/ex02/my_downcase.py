def my_downcase(string):
    lower_string = string.lower()
    return lower_string
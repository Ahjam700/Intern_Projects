def my_each(strings):
    # Iterate over each string in the array and call the print_func on each
    for string in strings:
        print(string)
    strings = [ "Blue", "Yellow", "Green", "Brown"]

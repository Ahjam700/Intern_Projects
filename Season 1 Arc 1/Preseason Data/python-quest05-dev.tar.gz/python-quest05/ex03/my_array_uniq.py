def my_array_uniq(integers):
    return list(set(integers))

# Example usage:
integers = [1, 2, 2, 3, 4, 4, 5]
result = my_array_uniq(integers)


    
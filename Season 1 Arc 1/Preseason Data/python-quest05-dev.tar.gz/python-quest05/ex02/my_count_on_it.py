def my_count_on_it(strings):
    return [len(string) for string in strings]

# Example usage:
strings = ["apple", "banana", "cherry"]
result = my_count_on_it(strings)





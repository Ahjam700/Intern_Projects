#include <stdio.h>

int my_mult(int param_1, int param_2) {
    return param_1 * param_2;  // Multiply the two parameters and return the result
}


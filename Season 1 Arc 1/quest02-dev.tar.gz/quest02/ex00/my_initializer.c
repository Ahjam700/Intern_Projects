#include <stdio.h>
#include <string.h>

void my_initializer(int* param_1) {
    *param_1 = 0;  // Dereference the pointer and set the value to 0
}

